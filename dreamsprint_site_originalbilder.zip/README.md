# Dreams Print – Bestellung (Templates + Upload + Online senden)

## Struktur
- index.html
- thankyou.html
- logo.png
- images/ (Produktbilder)
- templates/ (4 Vorlagen: Vorder- & Rückseite)

## Online automatisch senden (GitHub Pages)
GitHub Pages hat keinen Server. Darum brauchst du einen Formular-Dienst.
In `index.html` suche:
__FORM_ENDPOINT__
und ersetze es durch die URL deines Formular-Dienstes.

## Upload
Die Datei kann ausgewählt werden. Ob sie online mitgesendet wird, hängt von deinem Formular-Dienst ab.
Wenn nicht: Kunde soll Datei zusätzlich per WhatsApp/E-Mail senden.

## Schreibweise
Wir verwenden **T‑Shirt** (mit Bindestrich).


## Hoodie
- Farben: Schwarz/Weiss
- Preis: 30 CHF pro Stück
- Lieferzeit: 15 Tage (wird in Bestellung erwähnt)
